---
title: '2 - Version Control with Git and GitHub'
weight: 1
---

- Git terminology
- Working with a local repository
- Creating, initializing, and cloning a repository
- Basics of branching
- Staging and committing work
- Setting up remote repository (GitHub) and pushing local commits

{{< button "./git_and_github/" "Let's learn about Git! 💻" >}}
