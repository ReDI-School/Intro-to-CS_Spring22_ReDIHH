---
title: '1 - File System Basics'
weight: 1
---

- Basics of operating systems
- Linux file system hierarchy
- Navigation of Linux file system
- Working with files: Create, View, Manipulate
- Command line overview

{{< button "./intro/" "Let's learn about the computer's file system! 💻" >}}
