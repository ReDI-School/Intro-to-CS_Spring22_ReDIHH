---
title: '4 - Introduction to Web Development'
weight: 1
---

- Basic knowledge of HTML
- Basic knowledge of CSS
- Practical lesson demonstrating HTML & CSS
- Basic knowledge of JavaScript
- Practical lesson demonstrating HTML, CSS & JavaScript
- Job Opportunities (frontend dev)

{{< button "./basic_html/" "Basic knowledge of HTML 💻" >}}
