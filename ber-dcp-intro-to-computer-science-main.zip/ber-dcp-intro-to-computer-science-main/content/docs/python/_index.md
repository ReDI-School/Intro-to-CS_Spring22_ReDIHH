---
title: '3 - Programming in Python'
weight: 1
---

Programming fundamentals in Python including:

- Functions
- Data types
- Conditional logic (`if`, `elif`, `else` and boolean expressions)
- Control flow (`while` and `for` loops)
- Classes and objects

{{< button "./intro_to_python/" "Introduction to Python 💻" >}}
